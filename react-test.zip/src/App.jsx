// src/App.jsx
import { BrowserRouter, Routes, Route, Link, Navigate } from "react-router-dom";
import { useState, useEffect, useRef } from "react"; 

// Import halaman-halaman aplikasi
import PostList from "./pages/PostList";
import PostDetail from "./pages/PostDetail";
import CommentsPage from "./pages/CommentsPage";
import UserPage from "./pages/UserPage";
import NotFound from "./pages/NotFound";
import CreatePost from "./pages/CreatePost";
import EditPost from "./pages/EditPost";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";

// Import komponen dan hook Ant Design
import { Layout, Menu, Flex, message, Typography, Spin } from 'antd';
// Import ikon-ikon Ant Design
import { ReadOutlined, LoginOutlined, LogoutOutlined, UserOutlined } from '@ant-design/icons';

// Import konfigurasi dan konteks
import BASE_URL from "./apiConfig";
import { AuthProvider, useAuth } from './context/AuthContext';

// Import CSS aplikasi
import "./App.css";

// Destrukturisasi komponen-komponen Ant Design
const { Header, Content, Footer } = Layout;
const { Title } = Typography;

// Daftar user ID yang tersedia (digunakan untuk dummy data di fungsi CRUD jika auth belum diaktifkan sepenuhnya)
const AVAILABLE_USER_IDS = [1, 2, 3];


// --- Komponen AppCoreContent (inti aplikasi) ---
// Ini adalah komponen yang akan menggunakan AuthContext dan berisi logika utama aplikasi
function AppCoreContent() {
  // Menggunakan useAuth hook untuk mendapatkan status autentikasi dan fungsi logout
  const { isAuthenticated, user, token, logout } = useAuth(); 

  // State dan useEffect untuk animasi teks brand di header
  const [animatedText, setAnimatedText] = useState('');
  const fullText = 'KADA Academy 2025';
  const animationSpeed = 150; 
  const textRef = useRef(null); // Ini tidak digunakan, bisa dihapus

  useEffect(() => {
    let charIndex = 0;
    const animationInterval = setInterval(() => {
      if (charIndex < fullText.length) {
        setAnimatedText(fullText.substring(0, charIndex + 1));
        charIndex++;
      } else {
        clearInterval(animationInterval);
      }
    }, animationSpeed);
    return () => clearInterval(animationInterval);
  }, [fullText, animationSpeed]);

  // Handler untuk logout
  const handleLogout = async () => {
    const success = await logout();
    if (success) {
      window.location.href = '/'; // Redirect full page setelah logout
    }
  };

  // Fungsi CRUD (Create, Update, Delete) Postingan
  // Fungsi-fungsi ini akan mengirimkan JWT di header Authorization
  const addPost = async (newPost) => {
    try {
      if (!token) { // Pastikan ada token sebelum mengirim
        message.error('Authentication token missing. Please log in.');
        return false;
      }
      const randomUserId = AVAILABLE_USER_IDS[Math.floor(Math.random() * AVAILABLE_USER_IDS.length)];
      const postDataToSend = { ...newPost, imageUrl: newPost.imageUrl || `https://picsum.photos/seed/${Date.now()}/400/250`, userId: randomUserId };

      const response = await fetch(`${BASE_URL}/posts`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify(postDataToSend), credentials: 'include'
      });
      if (!response.ok) {
        const errorData = await response.json();
        if (response.status === 401 || response.status === 403) {
            message.error(errorData.message || 'Not authorized to create post. Please log in.');
            logout(); // Logout otomatis jika token tidak valid/expired
        }
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }
      message.success('Post created successfully!');
      return true;
    } catch (e) {
      console.error("Failed to add post:", e);
      message.error(e.message || 'An unexpected error occurred during post creation.');
      return false;
    }
  };

  const updatePost = async (updatedPost) => {
    try {
      if (!token) { // Pastikan ada token sebelum mengirim
        message.error('Authentication token missing. Please log in.');
        return false;
      }
      const response = await fetch(`${BASE_URL}/posts/${updatedPost._id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify(updatedPost), credentials: 'include'
      });
      if (!response.ok) {
        const errorData = await response.json();
        if (response.status === 401 || response.status === 403) {
            message.error(errorData.message || 'Not authorized to update post. Please log in.');
            logout();
        }
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }
      message.success('Post updated successfully!');
      return true;
    } catch (e) {
      console.error("Failed to update post:", e);
      message.error(e.message || 'An unexpected error occurred during post update.');
      return false;
    }
  };

  const deletePost = async (postIdToDelete) => {
    try {
      if (!token) { // Pastikan ada token sebelum mengirim
        message.error('Authentication token missing. Please log in.');
        return false;
      }
      const response = await fetch(`${BASE_URL}/posts/${postIdToDelete}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` },
        credentials: 'include'
      });
      if (!response.ok) {
        const errorData = await response.json();
        if (response.status === 401 || response.status === 403) {
            message.error(errorData.message || 'Not authorized to delete post. Please log in.');
            logout();
        }
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }
      message.success('Post deleted successfully!');
      return true;
    } catch (e) {
      console.error("Failed to delete post:", e);
      message.error(e.message || 'An unexpected error occurred during post deletion.');
      return false;
    }
  };

  // --- DEFINISI ITEM MENU DI SINI (SEBELUM RETURN) ---
  const mainMenuItems = [ // Menu utama di kiri (Posts)
    { key: '2', label: <Link to="/posts">Posts</Link>, style: { fontFamily: 'Poppins', fontWeight: '600' } },
  ];

  const authMenuItems = isAuthenticated ? ( // Menu autentikasi (Welcome/Logout)
    [
      { key: 'welcome', label: `Welcome, ${user?.username || 'User'}!`, style: { pointerEvents: 'none', color: '#333' } },
      { key: 'logout', label: 'Logout', icon: <LogoutOutlined />, onClick: handleLogout },
    ]
  ) : ( // Menu autentikasi (Login/Signup)
    [
      { key: 'login', label: <Link to="/auth/login">Login</Link>, icon: <LoginOutlined />, style: { marginLeft: 'auto' } },
      { key: 'signup', label: <Link to="/auth/signup">Sign Up</Link>, icon: <UserOutlined /> },
    ]
  );
  // --- AKHIR DEFINISI ITEM MENU ---

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Header style={{
          display: 'flex', alignItems: 'center', backgroundColor: '#fff',
          padding: '0 20px', position: 'fixed', width: '100%', top: 0, zIndex: 10
      }}>
        <div style={{ marginRight: '20px' }}>
          <Link to="/posts" style={{ textDecoration: 'none', color: 'inherit' }}>
            <Title
              level={3}
              style={{
                margin: 0, color: '#001529', whiteSpace: 'nowrap',
                fontFamily: 'Poppins, sans-serif', fontWeight: '600'
              }}
            >
              {animatedText}
            </Title>
          </Link>
        </div>
        {/* Menggunakan properti 'items' untuk Menu utama (menggantikan children deprecated) */}
        <Menu theme="light" mode="horizontal" defaultSelectedKeys={['2']} 
              style={{ flex: 1, minWidth: 0, borderBottom: 'none' }}
              items={mainMenuItems} // Menggunakan array items
        />
        {/* Menu untuk Login/Logout di kanan atas (juga menggunakan properti 'items') */}
        <Menu theme="light" mode="horizontal" style={{ borderBottom: 'none' }} items={authMenuItems} />
      </Header>
      <Content style={{ padding: '0 50px', marginTop: 84, paddingTop: 64 }}>
        <Flex justify="center" align="flex-start" style={{
          padding: 24, minHeight: 380, background: '#fff', borderRadius: '8px'
        }}>
          <Routes>
            <Route path="/" element={<Navigate to="/posts" replace />} />
            <Route path="/posts" element={<PostList />} />
            <Route path="/posts/create" element={<CreatePost addPost={addPost} />} />
            <Route path="/posts/:postId" element={<PostDetail deletePost={deletePost} />} />
            <Route path="/posts/:postId/edit" element={<EditPost updatePost={updatePost} />} />
            <Route path="/posts/:postId/comments" element={<CommentsPage />} />
            <Route path="/users/:userId" element={<UserPage />} />
            
            <Route path="/auth/login" element={<LoginPage />} />
            <Route path="/auth/signup" element={<SignupPage />} />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </Flex>
      </Content>
      <Footer style={{ textAlign: 'center', position: 'relative', overflow: 'hidden', backgroundColor: '#fff' }}>
        <div style={{ height: '40px', position: 'relative', overflow: 'hidden', width: '100%' }}>
          <div style={{
            display: 'flex', alignItems: 'center', gap: '3rem',
            animation: 'scrollLeft 25s linear infinite',
            minWidth: '200%',
            justifyContent: 'space-around'
          }}>
            {/* Logo List (jika ada) */}
            {/* Anda bisa tambahkan logoList di sini jika diperlukan */}
          </div>
        </div>
        <div style={{ marginTop: 84 }}>
          Copyright ©{new Date().getFullYear()} Giovaldi Ramadhan. All rights reserved.
        </div>
      </Footer>
    </Layout>
  );
}

// --- Komponen AppWrapper baru untuk menangani loader autentikasi awal ---
// Ini akan menjadi child langsung dari AuthProvider
function AppWrapper() {
  const { authLoading } = useAuth(); // useAuth sekarang dipanggil di dalam AuthProvider

  if (authLoading) {
    return (
      <Layout style={{ minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <Spin size="large" tip="Loading authentication..." />
      </Layout>
    );
  }

  return <AppCoreContent />; // Render inti aplikasi setelah loading autentikasi selesai
}

// --- Komponen App utama yang hanya menyediakan BrowserRouter dan AuthProvider ---
function App() {
  return (
    <BrowserRouter>
      <AuthProvider> {/* AuthProvider harus membungkus komponen yang mengonsumsi konteks */}
        <AppWrapper /> {/* AppWrapper akan menangani loading dan merender AppCoreContent */}
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;