// src/apiConfig.js
const BASE_URL = "http://localhost:3000"; // Sesuaikan dengan port backend Anda

export default BASE_URL;